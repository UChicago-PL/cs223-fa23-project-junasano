module Main where
import Diagrams.Prelude hiding (image)
import Diagrams.Backend.SVG.CmdLine
import Data.Colour.Palette.ColorSet (colourSpectrum)
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE TypeFamilies #-}
import Data.Complex

triangleShape :: Diagram B
triangleShape = eqTriangle 1


sierpinski :: Int -> Diagram B
sierpinski 0 = triangleShape
sierpinski n = s
             ===
             (s ||| s)  # centerX
  where s = sierpinski (n-1) # scale (1/2)

mandelbrotGenerator :: Int -> Int -> (Double, Double) -> Diagram B
mandelbrotGenerator maxIter edge (minC, maxC) = image # bgFrame 5 white
    where 
        quadratic c z = z*z + c
        critical_orbit c = iterate (quadratic c) 0
        pixel c = length . takeWhile (\z -> magnitude z <= 2) . take maxIter $ critical_orbit c
        side n v0 v1 =
            let sv = (v1 - v0) / fromIntegral n
            in  [v0, (v0 + sv) .. v1]

         -- Generate the grid of complex numbers
        sideX = side edge minC maxC
        sideY = side edge minC maxC
        grid = [ [x :+ y | x <- sideX] | y <- sideY ]

        -- Generate the image from the grid
        image = vcat . map hcat $ map (map (toSquare . pixel)) grid
        colorScale n = take n $ cycle (colourSpectrum 360)

        -- Convert a pixel value to a square with appropriate opacity
        toSquare :: Int -> Diagram B
        toSquare n = square 1 # lwG 0.01 # fc (colorScale maxIter !! n)





-- Main function to generate the SVG file
main :: IO ()
main = mainWith (mandelbrotGenerator 64 256 (-2, 2))
